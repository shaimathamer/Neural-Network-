%This Project to predict the cost matrix in automatic way 
%using neural network,The idea Behind this is to embedded the graph to vector space 
%and learn substitution,insertion and deletion cost 
%Shaima Algabli 
clear;
clc;
dbstop if error
Registers=[];
from_letter=1;
to_letter=15;
from_reg=1;
to_reg=2500;
% to_reg=250
max_reg=2500;
% max_reg=250;
for i=from_letter-1:to_letter-1
    for j=from_reg-1:to_reg-1
        Registers=[Registers i*max_reg+j+1];
    end
end
%%%%%%%%%%%%%%%Learning the Cost Matrix 
 Generate_Neural('LETTERHIGH','NN',Registers);
%%%%%%%%%BUILDING THE COST_Matrix%%%%%%%%%%%%%%%%%%
[CMatrix]=Building_Cost_Matrix('LETTERHIGH',Registers);
