function [input] = NN_INS_input(na,ea)
    input=[na,sum(ea)];
end
